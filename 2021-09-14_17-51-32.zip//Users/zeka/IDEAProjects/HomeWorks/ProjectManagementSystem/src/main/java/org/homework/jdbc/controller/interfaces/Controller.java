package org.homework.jdbc.controller.interfaces;

public interface Controller {

    void start();

    void close();
}
