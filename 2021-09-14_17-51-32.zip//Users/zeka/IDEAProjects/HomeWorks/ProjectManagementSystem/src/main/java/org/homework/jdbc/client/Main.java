package org.homework.jdbc.client;

import org.homework.jdbc.controller.CommandImpl;

public class Main {

    public static void main(String[] args) {

        new CommandImpl().start();
    }
}
