# USE homework;
#
# INSERT INTO companies(id, name, city)
# VALUES (1,'Juniors-group ','Odessa'),
#  (2,'IT-Rocks','Kiyv'),
#  (3,'TeleTili','Dnipro'),
#  (4, 'Ti v IT', 'Lviv'),
#  (5, 'IT-chub', 'Ternopil');
#
# INSERT INTO customers(id, name, city, budget)
# VALUES  (1,'Metro','Lviv', 1000000),
# (2,'VR','Kyiv', 1500000),
# (3,'Neighbour','Dnipro', 850000),
# (4,'Mama','Odessa', 2000000),
# (5,'Laze-Group','ZP-city', 1600000);
#
#
# INSERT INTO developers(id, name, age, gender, email, number_phone, salary)
# VALUES (1, 'Вася', 35, 'Male', 'abc@com.ua', 8765431, 2500),
#        (2, 'Коля', 25, 'Male', 'abc1@com.ua', 8765432, 3500),
#        (3, 'Костя', 26, 'Male', 'abc2@com.ua', 8765433, 4500),
#        (4, 'Витя', 27, 'Male', 'abc3@com.ua', 8765434, 2000),
#        (5, 'Юра', 28, 'Male', 'abc4@com.ua', 8765435, 3000),
#        (6, 'Ира', 29, 'Female', 'abc5@com.ua', 8765436, 4000),
#        (7, 'Дима', 30, 'Male', 'abc6@com.ua', 8765437, 5000),
#        (8, 'Катя', 32, 'Female', 'abc7@com.ua', 8765438, 6000),
#        (9, 'Антон', 33, 'Male', 'abc8@com.ua', 8765439, 5500),
#        (10, 'Лена', 36, 'Female', 'abc9@com.ua', 8765440, 6500),
#        (11, 'Маша', 40, 'Female', 'abc10@com.ua', 8765441, 2500),
#        (12, 'Миша', 42, 'Male', 'abc11@com.ua', 8765442, 4000);
#
# INSERT INTO skills(id, activities, level)
# VALUES (1, 'Java', 'Senior'),
#        (2, 'JS', 'Senior'),
#        (3, 'C++', 'Senior'),
#        (4, 'C#', 'Senior'),
#        (5, 'Java', 'Middle'),
#        (6, 'JS', 'Middle'),
#        (7, 'C++', 'Middle'),
#        (8, 'C#', 'Middle'),
#        (9, 'Java', 'Junior'),
#        (10, 'JS', 'Junior'),
#        (11, 'C++', 'Junior'),
#        (12, 'C#', 'Junior');
#
# INSERT INTO developers_skills(id_developer, id_skill)
# VALUES  (1,12), (1,9), (2,4), (3,1), (3,6), (4, 10), (5,7),(6,5), (7,2), (8,11),(9,8), (10,10), (1,3);
#
#
# INSERT INTO projects VALUES
#                          (1,'Apple',25000, '2020-10-12'),
#                          (2, 'Windows',20000, '2020-11-13'),
#                          (3, 'Google advance',300000, '2020-12-15'),
#                          (4, 'CaTTom',50000, '2021-02-15'),
#                          (5, 'Tesla',100000, '2021-03-12');
#
# INSERT INTO developers_projects(id_developer, id_project)
# VALUES  (1,2),(3,1),(5,1), (2,3),(7,2),(10,3),(8,3), (1,4),(7,4),(4,3), (9,5),(7,5),(1,5);
#
# INSERT INTO companies_projects VALUES
# (1,1),(2,2),(3,3),(4,4),(5,5);
#
# INSERT INTO customers_projects VALUES
# (1,4),(2,2),(3,1),(4,5),(5,3);
#
#
# # ALTER TABLE developers
# #     ADD salary DECIMAL;
# #
# # ALTER TABLE projects
# #     ADD cost DECIMAL;
# #
# # ALTER TABLE projects
# #     ADD first_date datetime default CURRENT_TIMESTAMP;
#
#
# # UPDATE developers
# # SET salary = 7600
# # WHERE name = 'Вася';
# #
# # UPDATE developers
# # SET salary = 6660
# # WHERE name = 'Коля';
# #
# # UPDATE developers
# # SET salary = 3600
# # WHERE name = 'Костя';
# #
# # UPDATE developers
# # SET salary = 5600
# # WHERE name = 'Витя';
# #
# # UPDATE developers
# # SET salary = 3600
# # WHERE name = 'Юра';
# #
# # UPDATE developers
# # SET salary = 1750
# # WHERE name = 'Ира';
# #
# # UPDATE developers
# # SET salary = 2750
# # WHERE name = 'Дима';
# #
# # UPDATE developers
# # SET salary = 2550
# # WHERE name = 'Катя';
# #
# # UPDATE developers
# # SET salary = 4750
# # WHERE name = 'Антон';
# #
# # UPDATE developers
# # SET salary = 2250
# # WHERE name = 'Лена';
# #
# # UPDATE developers
# # SET salary = 5550
# # WHERE name = 'Маша';
# #
# # UPDATE developers
# # SET salary = 8750
# # WHERE name = 'Миша';
#
#
# # UPDATE projects
# # SET cost = 50000
# # WHERE id = 1;
# #
# # UPDATE projects
# # SET cost = 25000
# # WHERE id = 2;
# #
# # UPDATE projects
# # SET cost = 70000
# # WHERE id = 3;
#
#
# # SELECT SUM(developers.salary) AS sum_salary, projects.name
# # FROM developers_projects
# #          inner join developers on developers_projects.id_developer = developers.id
# #          inner join projects on developers_projects.id_project = projects.id
# # GROUP BY projects.name
# # ORDER BY MAX(sum_salary)
# # limit 1;
#
# # select activities, SUM(developers.salary) AS totalSalary
# # from developers_skills
# #          inner join developers on developers_skills.id_developer = developers.id
# #          inner join skills on developers_skills.id_skill = skills.id
# # WHERE activities = 'Java';
#
# # SELECT projects.name, MIN(projects.cost) AS min_cost
# # FROM projects
# # GROUP BY projects.name
# # ORDER BY min_cost
# # limit 1;
#
# # SELECT projects.name, MIN(projects.cost) AS min_cost, AVG(developers.salary) AS avg_salary
# # FROM developers_projects
# #          inner join developers on developers_projects.id_developer = developers.id
# #          inner join projects on developers_projects.id_project = projects.id
# # GROUP BY projects.name
# # ORDER BY min_cost
# # limit 1;
#
#
#
