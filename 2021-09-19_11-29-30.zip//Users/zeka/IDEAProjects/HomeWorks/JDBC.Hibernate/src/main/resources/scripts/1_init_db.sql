﻿# DROP DATABASE IF EXISTS homework;
# CREATE DATABASE IF NOT EXISTS homework;
# USE homework;
#
# CREATE TABLE companies
# (
#     id   INT not null AUTO_INCREMENT,
#     name VARCHAR(40) NOT NULL,
#     city VARCHAR(40) NOT NULL,
#     PRIMARY KEY (id)
# );
#
# CREATE TABLE customers
# (
#     id         INT not null AUTO_INCREMENT,
#     name       VARCHAR(40) NOT NULL,
#     city       VARCHAR(40) NOT NULL,
#     budget     DECIMAL(12) NOT NULL,
#     PRIMARY KEY (id)
# );
#
# CREATE TABLE developers
# (
#     id           INT not null AUTO_INCREMENT,
#     name         VARCHAR(30) NOT NULL,
#     age          INT (3) NOT NULL,
#     gender       ENUM ('Male','Female') NOT NULL,
#     email        VARCHAR(30) NOT NULL,
#     number_phone BIGINT(15) NOT NULL,
#     salary       DECIMAL(10) NOT NULL,
#     PRIMARY KEY (id)
# );
#
# CREATE TABLE skills
# (
#     id         INT not null AUTO_INCREMENT,
#     activities ENUM ('Java','C++','C#','JS') NOT NULL,
#     level      ENUM ('Junior','Middle','Senior') NOT NULL,
#         PRIMARY KEY (id)
# );
#
# CREATE TABLE projects
# (
#     id          INT not null AUTO_INCREMENT,
#     name        VARCHAR(40) NOT NULL,
#     cost        DECIMAL(10) NOT NULL,
#     first_date  DATETIME DEFAULT CURRENT_TIMESTAMP,
#     PRIMARY KEY (id)
# );
#
# # CREATE TABLE developers_projects
# # (
# #     developer_id int NOT NULL,
# #     project_id   int NOT NULL,
# #     PRIMARY KEY (developer_id, project_id),
# #     FOREIGN KEY (developer_id) REFERENCES developers (id) ON DELETE CASCADE ON UPDATE CASCADE,
# #     FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE ON UPDATE CASCADE
# # );
# #
# # CREATE TABLE developers_skills
# # (
# #     developer_id int NOT NULL,
# #     skill_id    int NOT NULL,
# #     PRIMARY KEY (developer_id, skill_id),
# #     FOREIGN KEY (developer_id) REFERENCES developers (id) ON DELETE CASCADE ON UPDATE CASCADE,
# #     FOREIGN KEY (skill_id) REFERENCES skills (id) ON DELETE CASCADE ON UPDATE CASCADE
# # );
# CREATE TABLE developers_skills (
#                                    id_developer int NOT NULL,
#                                    id_skill int NOT NULL,
#                                    PRIMARY KEY (id_developer, id_skill),
#                                    FOREIGN KEY (id_developer) REFERENCES developers (id),
#                                    FOREIGN KEY (id_skill) REFERENCES skills (id));
#
# CREATE TABLE developers_projects (
#                                      id_developer int NOT NULL,
#                                      id_project int NOT NULL,
#                                      PRIMARY KEY (id_developer, id_project),
#                                      FOREIGN KEY (id_developer) REFERENCES developers (id),
#                                      FOREIGN KEY (id_project) REFERENCES projects (id));
#
# CREATE TABLE companies_projects (
#                                     id_company int NOT NULL,
#                                     id_project int NOT NULL,
#                                     PRIMARY KEY (id_company, id_project),
#                                     KEY id_project (id_project),
#                                     FOREIGN KEY (id_company) REFERENCES companies (id),
#                                     FOREIGN KEY (id_project) REFERENCES projects (id));
#
# CREATE TABLE customers_projects (
#                                     id_customer int NOT NULL,
#                                     id_project int NOT NULL,
#                                     PRIMARY KEY (id_customer, id_project),
#                                     KEY id_project (id_project),
#                                     FOREIGN KEY (id_customer) REFERENCES customers (id),
#                                     FOREIGN KEY (id_project) REFERENCES projects (id));