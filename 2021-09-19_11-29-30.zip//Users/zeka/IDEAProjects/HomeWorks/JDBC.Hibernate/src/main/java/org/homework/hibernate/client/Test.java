//package org.homework.hibernate.client;
//
//import org.homework.hibernate.model.Company;
//import org.homework.hibernate.model.Developer;
//import org.homework.hibernate.model.Project;
//import org.homework.hibernate.repository.CrudRepository;
//import org.homework.hibernate.repository.RepositoryFactory;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;
//import java.util.stream.StreamSupport;
//
//public class Test {
//    public static void main(String[] args) {
//       // CrudRepository<Company,Long> crudRepository = RepositoryFactory.of(Company.class);
//        CrudRepository<Developer,Long> crudRepository2 = RepositoryFactory.of(Developer.class);
//        CrudRepository<Project,Long> crudRepository3 = RepositoryFactory.of(Project.class);
//
//
//        System.out.println(crudRepository2.findById(1L));
//        System.out.println(crudRepository3.findById(1L));
//
//       // System.out.println(testStreamSpliterator().get(1));
//       // System.out.println(testStreamSpliterator().get(1));
//
//
//       // crudRepository.close();
//    }
//
//    public static List<? extends Class<? extends Developer>> testStreamSpliterator(){
//        Iterable<Developer> developerIterable = new ArrayList<>();
//        return StreamSupport.stream(developerIterable.spliterator(), false).map(entity->entity.getClass()).collect(Collectors.toList());
//    }
//}
