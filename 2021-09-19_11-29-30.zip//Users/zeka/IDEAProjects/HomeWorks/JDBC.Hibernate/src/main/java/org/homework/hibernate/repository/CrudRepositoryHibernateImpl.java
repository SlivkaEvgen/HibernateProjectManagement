package org.homework.hibernate.repository;

import lombok.SneakyThrows;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.homework.hibernate.model.BaseModel;
import org.homework.hibernate.utils.HibernateSessionFactory;
import org.homework.hibernate.utils.SessionsOpenClose;

import java.io.Closeable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class CrudRepositoryHibernateImpl<T extends BaseModel<ID>, ID> implements Closeable, CrudRepository<T, ID> {

    private final Class<T> modelClass;
    private final SessionsOpenClose sessionsOpenClose;// = new SessionsOpenClose();

    public CrudRepositoryHibernateImpl(Class<T> modelClass) {
        this.modelClass = modelClass;
        this.sessionsOpenClose = SessionsOpenClose.getInstance();
    }
//  вместо листов и сетов использовать Iterable, можно итерироваться как угодно и запихнуть лист,лист и т.п
    //  пример ->  for(T t: itrbl)

    @Override
    public List<T> saveAll(Iterable<T> itrb) {
        Session session = sessionsOpenClose.createSession();
        return StreamSupport.stream(itrb.spliterator(), false) // если тру - многопоточка / // itrb.iterator();
                .map(this::save)                                                                   ////for(T t: itrbl)
                .collect(Collectors.toList());
    }

    @Override
    public T save(T t) {
        Session session = sessionsOpenClose.createSession();
        ID id = t.getId() == null ? save(t, session) : update(t);
        Optional<T> result = getById(id, session);
//        session.getTransaction().commit();
        sessionsOpenClose.closeSession(session);
        return result.get();
        //getById(t.getId(), session);
//        if (t.getId() == null) {
//            ID saveId = save2(t, session);
//        }else {
//            ID updateId = update2(t, session);
//        }
//        getById(t.getId(), session);
//
//        ID id2 = (ID) session.save(t);
    }

    public ID save(T t, Session session) {
        return (ID) session.save(t);
    }

    @Override
    public ID update(T t) {
        Session session = sessionsOpenClose.createSession();
        session.saveOrUpdate(t);
        ID id = update(t, session);
        session.close();
        return id;
    }

    private ID update(T t, Session session) {
       // session.update(t);
        return t.getId();
    }

//    @Override
//    public ID updates(T t) {
//        return updates(t, SessionsOpenClose.getInstance().createSession());
//    }

//    @Override
//    public T create(T t) {
//        Session session = sessionsOpenClose.createSession();
////session.getCriteriaBuilder().sum(Class.forName("salary"))
////        session.createQuery("")
////        JpaCriteriaQuery<T> query = session.getCriteriaBuilder().createQuery(modelClass);
//        session.update(t);
//        return t;
//    }

    @Override
    public void deleteById(ID id) {
        Session session5 = sessionsOpenClose.createSession();
        getById(id, session5).ifPresent(entity -> session5.remove(entity));
        sessionsOpenClose.closeSession(session5);
    }

    @Override
    public Optional<T> findById(ID id) {
        Session session = sessionsOpenClose.createSession();
        Optional<T> result = getById(id, session);
        sessionsOpenClose.closeSession(session);
        return result;
    }

    @SneakyThrows
    @Override
    public List<T> findAll() {
        Session session = sessionsOpenClose.createSession();
        JpaCriteriaQuery<T> query = session.getCriteriaBuilder().createQuery(modelClass);
        List<T> resultList = session.createQuery(query.select(query.from(modelClass))).getResultList();
        sessionsOpenClose.closeSession(session);
        return resultList;
        // Query<T> sessionQuery = session.createQuery(query.select(query.from(modelClass)));
//        List<T> resultList2 = session.createQuery(query.select(query.from(modelClass))).getResultList();
    }

    private Optional<T> getById(ID id, Session session) {
        return Optional.ofNullable(session.get(modelClass, id));
    }

    @Override
    public void close() {
        HibernateSessionFactory.close();
    }
}
