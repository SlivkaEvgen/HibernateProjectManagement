//package org.homework.hibernate.repository.hw4.interfaces;
//
//import org.homework.hibernate.model.Project;
//
//import java.util.List;
//
//public interface ProjectRepository extends CrudRepository<Project, Long> {
//
//    List<String> getListProjectsWithDate();
//}
