package org.homework.hibernate.service.hw4;

import org.homework.hibernate.model.Skill;
import org.homework.hibernate.repository.CrudRepository;
import org.homework.hibernate.repository.RepositoryFactory;
import org.homework.hibernate.service.hw4.interfaces.SkillService;

import java.util.List;
import java.util.Optional;

public class SkillServiceImpl implements SkillService {

    private final CrudRepository<Skill, Long> CRUD_REPOSITORY = RepositoryFactory.of(Skill.class);

    @Override
    public Optional<Skill> getById(Long id) {
        return CRUD_REPOSITORY.findById(id);
    }

    @Override
    public List<Skill> getAll() {
        return CRUD_REPOSITORY.findAll();
    }

    @Override
    public Skill createNewSkill(String activity, String level) {
        Skill skill = new Skill();
        skill.setActivities(activity);
        skill.setLevel(level);
        return CRUD_REPOSITORY.create(skill);
    }

    @Override
    public void update(Long id, String activity, String level) {
        Skill skill = new Skill();
        skill.setActivities(activity);
        skill.setLevel(level);
        CRUD_REPOSITORY.update(skill);
    }

    @Override
    public void delete(Long id) {
        CRUD_REPOSITORY.deleteById(id);
    }

    public void method(){
//        CRUD_REPOSITORY.save();
//        CRUD_REPOSITORY.saveAll();
        CRUD_REPOSITORY.close();
    }
}
