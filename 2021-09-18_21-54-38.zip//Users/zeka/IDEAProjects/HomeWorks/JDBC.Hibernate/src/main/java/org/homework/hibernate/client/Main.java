package org.homework.hibernate.client;

import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaDelete;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.homework.hibernate.controller.hw4.CommandImpl;
import org.homework.hibernate.model.*;
import org.homework.hibernate.utils.HibernateSessionFactory;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {

        //  new CommandImpl().start();

//        System.out.println("Hibernate tutorial");
//
        Session session = HibernateSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();

        List<Developer> developerList = loadAllData(Developer.class, session);
        List<Project> projectList = loadAllData(Project.class, session);
        List<Customer> customerList = loadAllData(Customer.class, session);
        List<Skill> skillList = loadAllData(Skill.class, session);
        List<Company> companyList = loadAllData(Company.class, session);

        //JpaCriteriaDelete<Developer> criteriaDelete = session.getCriteriaBuilder().createCriteriaDelete(Developer.class);
//        System.out.println("--------------------------------------------------------------------------------------");
//        System.out.println(developerList);
//        System.out.println("--------------------------------------------------------------------------------------");
//        System.out.println(projectList);
//        System.out.println("--------------------------------------------------------------------------------------");
//        System.out.println(customerList);
//        System.out.println("--------------------------------------------------------------------------------------");
//        System.out.println(skillList);
//        System.out.println("--------------------------------------------------------------------------------------");
//        System.out.println(companyList);
//        System.out.println("--------------------------------------------------------------------------------------");
        System.out.println("/////////////////ALL/ALL//ALL/ALL//ALL/ALL//ALL/ALL//ALL/ALL//ALL/ALL//ALL/ALL//ALL/ALL/");

        System.out.println("/////////////////BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID/");
//        System.out.println(developerList.get(0));
//        System.out.println(projectList.get(0));
//        System.out.println(companyList.get(0));
//        System.out.println(customerList.get(0));
//        System.out.println(skillList.get(0));
        System.out.println("/////////////////BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID//BYID/BYID/");
        System.out.println("/////////////////DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/DELETE/");
//developerList.remove(11);
      //  session.delete(session.get(Developer.class, 12));
        session.delete(session.get(Skill.class, 1));
        session.getTransaction().commit();
        session.close();

//        List<Project> projectList = loadAllData(Project.class, session);
//        List<Company> companyList = loadAllData(Company.class, session);
//        List<Customer> customerList = loadAllData(Customer.class, session);
//        List<Skill> skillList = loadAllData(Skill.class, session);
//        List<Developer> developerList = loadAllData(Developer.class, session);
//        JpaCriteriaDelete<Developer> criteriaDelete = session.getCriteriaBuilder().createCriteriaDelete(Developer.class);
//        session.delete(session.get(Developer.class, 12));
//        System.out.println(developerList);
//        System.out.println(projectList);
//        System.out.println(companyList);
//        System.out.println(customerList);
//        System.out.println(skillList);

//session.createQuery(query.select(query.from(Developer.class)).where(id=));
//        Developer remove = developerList.remove(11);
//        System.out.println(remove);
//        System.out.println("________________________________________________________________");
//        List<Developer> developers = new ArrayList<>();
//        for (int i = 0; i < developerList.size(); i++) {
//            Developer developer = developerList.get(i);
////            Set<Skill> skills = developer.getSkills();
//            List<Skill> skillsList = new ArrayList<>(developer.getSkills());
//            for (int j = 0; j < skillsList.size(); j++) {
//                Skill skill = skillsList.get(j);
//                String activities = skill.getActivities();
//                if (activities.equalsIgnoreCase("js")){
//                    System.out.println(developer.getSkills());
//                    developers.add(developer);
//                }
//            }
//        }
//        System.out.println(developers);

//        List<Developer> developers = new ArrayList<>();
//        Set<Skill> skills = developers.get(2).getSkills();
//            List<Skill> skillsList = new ArrayList<>(developers.get(2).getSkills());
//        System.out.println(skillsList.get(0));
//        for (int i = 0; i <developerList.size(); i++) {
//            Developer developer = developerList.get(i);
//            System.out.println(developer.getId());
//            System.out.println(developer.getSkills());
//            //            Set<Skill> skills = developer.getSkills();
//            List<Skill> skillsList = new ArrayList<>(developer.getSkills());
//
//            for (Skill skill : skillsList) {
//                String level = skill.getLevel();
//                System.out.println(level);
//                if (level.equalsIgnoreCase("middle")) {
////                    System.out.println(developer.getSkills());
//                    developers.add(developer);
//                }
//            }
//        }
//
//        System.out.println(developers);
//
//        System.out.println("________________________________________________________________");
//        Company company = session.get(Company.class, 1L);
//        System.out.println(company);
//        Set<Project> projects = company.getProjects();
//        System.out.println(projects);
//        System.out.println("________________________________________________________________");
//
//        Customer customer = session.get(Customer.class, 4L);
//        System.out.println(customer);
//        Set<Project> projects2 = customer.getProjects();
//        System.out.println(projects2);
//        System.out.println("________________________________________________________________");
//        Project project = session.get(Project.class, 1L);
//        Set<Developer> developers = project.getDevelopers();
//        System.out.println(project);
//        List<Developer> developerList = developers.stream().collect(Collectors.toList());
//        System.out.println(developerList);
//        Long totalSalaries = 0L;
//        for (int i = 0; i < developerList.size(); i++) {
//            Long salary = developerList.get(i).getSalary();
//            totalSalaries = totalSalaries + salary;
//        }
//        System.out.println(totalSalaries);
//        System.out.println("________________________________________________________________");
//        Skill skill = session.get(Skill.class, 11L);
//        Set<Developer> developers1 = skill.getDevelopers();
//        System.out.println(skill);
//        System.out.println(developers1);
//        System.out.println("________________________________________________________________");
//        Developer developer = session.get(Developer.class, 1L);
//        Set<Project> projects3 = developer.getProjects();
//        System.out.println(developer);
//        System.out.println(projects3);
//        System.out.println("________________________________________________________________");
//        Set<Skill> skills = developer.getSkills();
//        System.out.println(skills);
//        Set<Customer> customers = project.getCustomers();
//        Set<Project> projects = project.getProjects();
//        Set<Developer> developers = project.getDevelopers();

//        System.out.println(customers);
//        System.out.println(projects);
//        System.out.println(developers);

//        Customer customer = session.get(Customer.class, 1L);
//        System.out.println(customer);
//
//        Skill skill = session.get(Skill.class, 1L);
//        System.out.println(skill);

//        Project project = session.get(Project.class, 1L);
//        System.out.println(project);
//
//        Developer developer = session.get(Developer.class, 1L);
//        System.out.println(developer);
//        Project project = developer.getProject();
//        System.out.println(project);

//        System.out.println("________________________________________________________________");
//
//        System.out.println("________________________________________________________________");

//        System.out.println("*****************************************************************************");
///// GET ALL
//        System.out.println(companyList);
//
//        System.out.println(developerList);
//
//        System.out.println(projectList);
////
//        System.out.println(customerList);
////
//        System.out.println(skillList);
//////  GET BY ID
//        System.out.println(" BY ID ");

//        System.out.println(companyList.get(0));
//
//        System.out.println(developerList.get(0));
//
//        System.out.println(projectList.get(0));
//
//        System.out.println(customerList.get(0));
//
//        System.out.println(skillList.get(0));


//
//        Session session1 = HibernateSessionFactory.getSessionFactory().openSession();
//        session1.beginTransaction();

//        Company company = session1.get(Company.class, 4);
//        session1.remove(company);
//
//        session1.getTransaction().commit();
//        session1.close();
//
//        Session session2 = HibernateSessionFactory.getSessionFactory().openSession();
//        session2.beginTransaction();
//////JPQL vs HQL vs SQL  - чтобы не писать SQL запросы
//        List<Project> loadAllData1 = findAllWithJpql2(Project.class, session2);
//        System.out.println(loadAllData1);
//
//        List<Company> loadAllData = findAllWithJpql(Company.class, session2);
//        System.out.println(loadAllData);
//
//        session2.getTransaction().commit();
//        session2.close();
    }

    //
//    private static <T> List<T> findAllWithJpql(Class<T> type, Session session) {
//        return session.createQuery("SELECT d FROM Developer d", type).getResultList();
//    }
//
//    private static <T> List<T> findAllWithJpql2(Class<T> type, Session session) {
//        return session.createQuery("SELECT p FROM Project p", type).getResultList();
//    }

    //
    private static <T> List<T> loadAllData(Class<T> type, Session session) {
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<T> criteria = builder.createQuery(type);
        criteria.from(type);
        List<T> data = session.createQuery(criteria).getResultList();
        return data;
    }

}
