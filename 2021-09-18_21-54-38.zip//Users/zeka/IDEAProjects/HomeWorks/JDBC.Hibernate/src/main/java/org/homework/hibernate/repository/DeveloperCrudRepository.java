package org.homework.hibernate.repository;

import org.hibernate.Session;
import org.homework.hibernate.model.Developer;

import java.util.List;
import java.util.Optional;

public interface DeveloperCrudRepository extends CrudRepository<Developer,Long>{

    Long getSumSalariesDevelopersOfOneProject(Long projectId);

    List<Developer> getDevelopersFromOneProject(Long projectId);

    List<Developer> getDevelopersByActivity(String nameActivity);

    List<Developer> getDevelopersByLevel(String nameLevel);
//
//    Optional<Developer> findById(Long id);
//
//    List<Developer> findAll();
//
//    Developer save(Developer e);
//
//    List<Developer> saveAll(Iterable<Developer> itrb);
//
//    Developer create(Developer e);
//
//    Long update(Developer e);
//
//    void deleteById(Long id);
//
//    void close();
}
