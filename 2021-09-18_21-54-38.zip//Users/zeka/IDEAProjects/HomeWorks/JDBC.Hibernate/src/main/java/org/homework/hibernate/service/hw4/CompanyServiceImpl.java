package org.homework.hibernate.service.hw4;

import org.homework.hibernate.model.Company;
import org.homework.hibernate.repository.CrudRepository;
import org.homework.hibernate.repository.RepositoryFactory;
import org.homework.hibernate.service.hw4.interfaces.CompanyService;

import java.util.List;
import java.util.Optional;

public class CompanyServiceImpl implements CompanyService {

    private final CrudRepository<Company, Long> CRUD_REPOSITORY = RepositoryFactory.of(Company.class);

    @Override
    public Optional<Company> getById(Long id) {
        return CRUD_REPOSITORY.findById(id);
    }

    @Override
    public List<Company> getAll() {
        return CRUD_REPOSITORY.findAll();
    }

    @Override
    public Company createNewCompany(String name, String city) {
        Company company = new Company();
        company.setName(name);
        company.setCity(city);
        return CRUD_REPOSITORY.create(company);
    }

    @Override
    public void update(Long id, String name, String city) {
        Company company = new Company();
        company.setName(name);
        company.setCity(city);
        CRUD_REPOSITORY.update(company);
    }

    @Override
    public void delete(Long id) {
        CRUD_REPOSITORY.deleteById(id);
    }
}
