package org.homework.hibernate.repository;

import org.hibernate.Session;
import org.homework.hibernate.model.Project;

import java.util.List;
import java.util.Optional;

public interface ProjectCrudRepository extends CrudRepository<Project,Long>{

    List<String> getListProjectsWithDate();

//    Optional<Project> findById(Long id);

//    List<Project> findAll();
//
//    Project save(Project project);
//
//    List<Project> saveAll(Iterable<Project> itrb);
//
//    Project create(Project project);
//
//    Long update(Project project);
//
//    void deleteById(Long id);
//
//    void close();
}
