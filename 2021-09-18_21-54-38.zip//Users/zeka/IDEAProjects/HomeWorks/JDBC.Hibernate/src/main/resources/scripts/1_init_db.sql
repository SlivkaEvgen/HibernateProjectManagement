﻿DROP DATABASE IF EXISTS homework;
CREATE DATABASE IF NOT EXISTS homework;
USE homework;

CREATE TABLE companies
(
    id   INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(40) NOT NULL,
    city VARCHAR(40) NOT NULL
);

CREATE TABLE customers
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(40) NOT NULL,
    city       VARCHAR(40) NOT NULL,
    budget     DECIMAL(12) NOT NULL
);

CREATE TABLE developers
(
    id           INT PRIMARY KEY AUTO_INCREMENT,
    name         VARCHAR(30) NOT NULL,
    age          INT (3) NOT NULL,
    gender       ENUM ('Male','Female') NOT NULL,
    email        VARCHAR(30) NOT NULL,
    number_phone BIGINT(15) NOT NULL,
    salary       DECIMAL(10) NOT NULL,
    company_id   INT NOT NULL,
    FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
);

CREATE TABLE skills
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    activities ENUM ('Java','C++','C#','JS') NOT NULL,
    level      ENUM ('Junior','Middle','Senior') NOT NULL
);

CREATE TABLE projects
(
    id          INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(40) NOT NULL,
    cost        DECIMAL(10) NOT NULL,
    first_date  DATETIME DEFAULT CURRENT_TIMESTAMP,
    company_id  INT NOT NULL,
    customer_id INT NOT NULL,
    FOREIGN KEY (company_id) REFERENCES companies (id)  ON DELETE CASCADE ,
    FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE
);

CREATE TABLE developers_projects
(
    developer_id int NOT NULL,
    project_id   int NOT NULL,
    PRIMARY KEY (developer_id, project_id),
    FOREIGN KEY (developer_id) REFERENCES developers (id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
);

CREATE TABLE developers_skills
(
    developer_id int NOT NULL,
    skill_id    int NOT NULL,
    PRIMARY KEY (developer_id, skill_id),
    FOREIGN KEY (developer_id) REFERENCES developers (id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills (id) ON DELETE CASCADE
);
