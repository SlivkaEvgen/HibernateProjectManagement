package org.homework.hibernate.service.hw4;

import org.homework.hibernate.model.Project;
import org.homework.hibernate.repository.ProjectCrudRepositoryImpl;
import org.homework.hibernate.service.hw4.interfaces.ProjectService;

import java.util.List;
import java.util.Optional;

public class ProjectServiceImpl implements ProjectService {

    private final ProjectCrudRepositoryImpl CRUD_REPOSITORY = new ProjectCrudRepositoryImpl(Project.class);

    @Override
    public Optional<Project> getById(Long id) {
        return CRUD_REPOSITORY.findById(id);
    }

    @Override
    public List<Project> getAll() {
        return CRUD_REPOSITORY.findAll();
    }

    @Override
    public Project createNewProject(String name, Long cost) {
        Project project = new Project();
        project.setName(name);
        project.setCost(cost);
        return CRUD_REPOSITORY.create(project);
    }

    @Override
    public void update(Long id, String name, Long cost) {
        Project project = new Project();
        project.setName(name);
        project.setCost(cost);
        CRUD_REPOSITORY.update(project);
    }

    @Override
    public void delete(Long id) {
        CRUD_REPOSITORY.deleteById(id);
    }

    @Override
    public List<String> getListProjectsWithDate() {
        return CRUD_REPOSITORY.getListProjectsWithDate();
    }
}
