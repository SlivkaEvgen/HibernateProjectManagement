//package org.homework.hibernate.controller.hw4;
//
//import com.google.gson.Gson;
//import com.google.gson.JsonSyntaxException;
//import lombok.SneakyThrows;
//import org.homework.hibernate.model.Company;
//import org.homework.hibernate.repository.CrudRepository;
//import org.homework.hibernate.repository.RepositoryFactory;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.SQLException;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//@WebServlet("/company/*")
//public class CompanyServlet extends HttpServlet {
//
//    private static final long serialVersionUID = 896666665456578L;
//
//    private final CrudRepository<Company, Long> repository = RepositoryFactory.of(Company.class);
//    private final Gson gson = new Gson();
//
//    public CompanyServlet() throws SQLException {
//    }
//
//    @Override
//    protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
//            throws ServletException, IOException {
//        getId(req, resp).ifPresent(id -> repository.deleteById(id));
//    }
//    //    System.out.println("x="+x++);
//    //        String pathInfo = req.getPathInfo();
//    //        String[] split = req.getPathInfo().split("/");
//    //        repository.deleteById(Long.valueOf(split[1]));
//    //        if (!userMap.containsKey(split[1])) {
//    //            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
//    //            return;
//    //        }
//    //        Company remove = userMap.remove(split[1]);
//    //        sendAsJson(resp, remove);
//
//    @SneakyThrows
//    private String sendError(HttpServletResponse resp, int httpStatus) {
//        resp.sendError(httpStatus);
//        return "Eroor response with status : " + httpStatus;
//    }
//
//    private Optional<Long> getId(HttpServletRequest req, HttpServletResponse resp)
//            throws IOException {
//        try {
//            final String[] split = req.getPathInfo().split("/");
//            if (split.length != 2) sendError(resp, HttpServletResponse.SC_BAD_REQUEST);
//            return Optional.of(Long.valueOf(split[1]));
//        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
//            sendError(resp, HttpServletResponse.SC_BAD_REQUEST);
//            return Optional.empty();
//        }
//    }
//
//    @Override
//    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//        try {
//            String payload = req.getReader().lines().collect(Collectors.joining("\n"));
//            Company company = gson.fromJson(payload, Company.class);
//            sendAsJson(resp, repository.save(company));
//        } catch (JsonSyntaxException e) {
//            sendError(resp, HttpServletResponse.SC_BAD_REQUEST);
//        }
//        //        System.out.println("x="+x++);
//        //        String payload = req.getReader().lines().collect(Collectors.joining("\n"));
//        //        Company company = gson.fromJson(payload, Company.class);
//        //        repository.save(company);
//        //        if (!userMap.containsKey(company.getId())) {
//        //            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
//        //            return;
//        //        }
//        //        userMap.put(String.valueOf(company.getId()), company);
//        //        sendAsJson(resp, repository.save(company));
//    }
//
//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//        doPut(req, resp);
//        // BufferedReader reader = req.getReader();
//        // String payload = CharStreams.toString(req.getReader());
//        //        String payload = req.getReader().lines().collect(Collectors.joining("\n"));
//        //        Company company = gson.fromJson(payload, Company.class);
//        //        String uuid = UUID.randomUUID().toString();
//        //        company.setId(Long.valueOf(uuid));
//        //        userMap.put(uuid, company);
//        //        sendAsJson(resp, company);
//    }
//
//    //    @SneakyThrows
//    //    public CompanyServlet() throws SQLException {
//    //        repository = RepositoryFactory.of(Company.class);
//    ////        String uuid1 = UUID.randomUUID().toString();
//    ////        userMap.put(
//    ////                uuid1,
//    ////                Company.builder().id(Long.valueOf(uuid1)).name("Mac").build());
//    ////        String uuid2 = UUID.randomUUID().toString();
//    ////        userMap.put(
//    ////                uuid2, Company.builder().id(Long.valueOf(uuid2)).name("APPLE").build());
//    //    }
//
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//        String pathInfo = req.getPathInfo();
//        if (pathInfo == null || pathInfo.equals("/")) {
//            //            Collection<Company> users = userMap.values();
//            sendAsJson(resp, repository.findAll());
//            return;
//        }
//
//        String[] split = pathInfo.split("/");
//
//        if (split.length != 2) {
//            resp.sendError(HttpServletResponse.SC_BAD_REQUEST); // 404
//            return;
//        }
//        //        if (!userMap.containsKey(split[1])) {
//        //            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
//        //            return;
//        //        }
//        sendAsJson(resp, repository.findById(Long.valueOf(split[1])));
//    }
//
//    private void sendAsJson(HttpServletResponse resp, Object payload) throws IOException {
//        resp.setContentType("application/json");
//        PrintWriter respWriter = resp.getWriter();
//        String toJson = gson.toJson(payload);
//        respWriter.print(toJson);
//        respWriter.flush();
//    }
//
//    //    @Override
//    //    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//    ////        System.out.println("x="+x++);
//    //        String payload = req.getReader().lines().collect(Collectors.joining("\n"));
//    //        Company company = gson.fromJson(payload, Company.class);
//    //        repository.save(company);
//    ////        if (!userMap.containsKey(company.getId())) {
//    ////            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
//    ////            return;
//    ////        }
//    ////        userMap.put(String.valueOf(company.getId()), company);
//    //        sendAsJson(resp, repository.save(company));
//    //    }
//    //
//    //    @Override
//    //    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) {
//    ////    System.out.println("x="+x++);
//    ////        String pathInfo = req.getPathInfo();
//    //        String[] split = req.getPathInfo().split("/");
//    //        repository.deleteById(Long.valueOf(split[1]));
//    ////        if (!userMap.containsKey(split[1])) {
//    ////            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
//    ////            return;
//    ////        }
//    ////        Company remove = userMap.remove(split[1]);
//    ////        sendAsJson(resp, remove);
//    //    }
//}
//// localhost:8080/ServletMVC/user->Get->all
//// localhost:8080/ServletMVC/user/1 ->get->user with id 1
