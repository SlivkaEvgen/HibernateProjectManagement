package org.homework.hibernate.client;

import org.hibernate.Session;
import org.homework.hibernate.model.*;
import org.homework.hibernate.utils.HibernateSessionFactory;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        // new CommandImpl().start();

        System.out.println("Hibernate tutorial");

        Session session = HibernateSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        List<Company> companyList = loadAllData(Company.class, session);
        List<Developer> developerList = loadAllData(Developer.class, session);
        List<Project> projectList = loadAllData(Project.class, session);
        List<Customer> customerList = loadAllData(Customer.class, session);
        List<Skill> skillList = loadAllData(Skill.class, session);

        System.out.println("*****************************************************************************");
///// GET ALL
//        System.out.println(companyList);
//
//        System.out.println(developerList);
//
//        System.out.println(projectList);
////
//        System.out.println(customerList);
////
//        System.out.println(skillList);
//////  GET BY ID
        System.out.println(" BY ID ");

//        System.out.println(companyList.get(0));
//
//        System.out.println(developerList.get(0));
//
//        System.out.println(projectList.get(0));
//
//        System.out.println(customerList.get(0));
//
//        System.out.println(skillList.get(0));

        session.getTransaction().commit();
        session.close();

        Session session1 = HibernateSessionFactory.getSessionFactory().openSession();
        session1.beginTransaction();

//        Company company = session1.get(Company.class, 4);
//        session1.remove(company);

        session1.getTransaction().commit();
        session1.close();

        Session session2 = HibernateSessionFactory.getSessionFactory().openSession();
        session2.beginTransaction();
//JPQL vs HQL vs SQL  - чтобы не писать SQL запросы
        List<Developer> loadAllData1 = findAllWithJpql(Developer.class, session2);
        System.out.println(loadAllData1);

        session2.getTransaction().commit();
        session2.close();
    }

    private static <T> List<T> findAllWithJpql(Class<T> type, Session session) {
        return session.createQuery("SELECT d FROM Developer d", type).getResultList();
    }

    private static <T> List<T> loadAllData(Class<T> type, Session session) {
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<T> criteria = builder.createQuery(type);
        criteria.from(type);
        List<T> data = session.createQuery(criteria).getResultList();
        return data;
    }

}
