package org.homework.hibernate.model;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"company","projects"})
@ToString(exclude = {"company"})
@Entity
@Table(name = "customers")
public class Customer implements BaseModel<Long> {

    private static final long serialVersionUID = 1928374651928374651L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true, unique = true)
    private Long id;

    @Column(name = "name", nullable = true, length = 30)
    private String name;

    @Column(name = "city", nullable = true, length = 30)
    private String city;

    @Column(name = "budget", nullable = true, length = 10)
    private Long budget;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Project> projects;
}
