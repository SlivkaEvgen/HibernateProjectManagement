package org.homework.hibernate.client;

import org.homework.hibernate.model.Company;
import org.homework.hibernate.model.Developer;
import org.homework.hibernate.model.Project;
import org.homework.hibernate.repository.CrudRepository;
import org.homework.hibernate.repository.RepositoryFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class Test {
    public static void main(String[] args) {
        CrudRepository<Company,Long> crudRepository = RepositoryFactory.of(Company.class);


        System.out.println(testStreamSpliterator().get(1));


        crudRepository.close();
    }

    public static List<? extends Class<? extends Developer>> testStreamSpliterator(){
        Iterable<Developer> developerIterable = new ArrayList<>();
        return StreamSupport.stream(developerIterable.spliterator(), false).map(entity->entity.getClass()).collect(Collectors.toList());

    }
}
