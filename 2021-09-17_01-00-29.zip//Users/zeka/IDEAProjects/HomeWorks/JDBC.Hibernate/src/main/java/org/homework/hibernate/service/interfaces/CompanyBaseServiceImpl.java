package org.homework.hibernate.service.interfaces;

import org.homework.hibernate.model.Company;
import org.homework.hibernate.service.BaseService;

public interface CompanyBaseServiceImpl {

    public class CompanyServiceImpl extends BaseService<Company,Long> {

    }
}
