package org.homework.hibernate.repository;

import org.homework.hibernate.model.BaseModel;

import java.util.Optional;

public interface QueryRepository<T extends BaseModel<ID>, ID> {

    Object getDevsByProID(ID id, Iterable<T> devInOnePro);

    Optional<T> listJava(String java);

    Optional<T> listMiddle(String middle);

    Object listProWithData(Iterable<T> devInOnePro);
}
