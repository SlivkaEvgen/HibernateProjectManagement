package org.homework.hibernate.service;

import org.homework.hibernate.model.BaseModel;

public abstract class BaseService <E extends BaseModel<ID>, ID>{

}