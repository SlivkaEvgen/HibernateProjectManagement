//package org.homework.hibernate.model;
//
//import lombok.*;
//
//import javax.persistence.*;
//
//@Data
//@Builder
//@AllArgsConstructor
//@NoArgsConstructor
//@Entity
//@Table(name = "developers")
//public class DeveloperOneToOne implements BaseModel<Long>{
//
//    private static final long serialVersionUID =777779999943233L;
//
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id", nullable = true, unique = true)
//    private Long id;
//
//    @Column(name = "name", nullable = true, length = 30)
//    private String name;
//
//    @Column(name = "salary", nullable = true, length = 10)
//    private Long salary;
//
//    @Column(name = "email", nullable = true, length = 30, unique = true)
//    private String email;
//}
