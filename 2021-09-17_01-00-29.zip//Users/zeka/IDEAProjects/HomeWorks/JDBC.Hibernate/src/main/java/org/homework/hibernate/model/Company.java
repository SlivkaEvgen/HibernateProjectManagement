package org.homework.hibernate.model;

import lombok.*;
import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"projects", "developers", "customers"})
@ToString(exclude = {"developers"})
@Entity
@Table(name = "companies")
public class Company implements BaseModel<Long> {

    private static final long serialVersionUID = 1928374651928374653L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true)
    private Long id;

    @Column(name = "name", nullable = true, length = 30, unique = false)
    private String name;

    @Column(name = "city", nullable = true, length = 40, unique = false)
    private String city;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Project> projects;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Developer> developers;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Customer> customers;
}
