package org.homework.hibernate.model;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"developers","customer","company"})
@ToString(exclude ={"customer","company"})
@Entity
@Table(name = "projects")
public class Project implements BaseModel<Long> {

    private static final long serialVersionUID = 1828374651928374654L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true, unique = true)
    private Long id;

    @Column(name = "name", nullable = true, length = 30)
    private String name;

    @Column(name = "cost", nullable = true, length = 10)
    private Long cost;

    @Column(name = "first_date", nullable = true, length = 40)
    private String firstDate;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(
            name = "developers_projects",
            joinColumns = {@JoinColumn(name = "developer_id")},
            inverseJoinColumns = {@JoinColumn(name = "project_id")})
    private Set<Developer> developers;
}
