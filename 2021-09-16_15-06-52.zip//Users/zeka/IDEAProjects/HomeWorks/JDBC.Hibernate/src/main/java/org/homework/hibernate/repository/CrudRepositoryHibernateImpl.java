package org.homework.hibernate.repository;

import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.homework.hibernate.model.BaseModel;
import org.homework.hibernate.utils.HibernateSessionFactory;

import java.io.Closeable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class CrudRepositoryHibernateImpl<T extends BaseModel<ID>, ID> implements Closeable,CrudRepository<T, ID> {

    private final Class<T> modelClass;

    CrudRepositoryHibernateImpl(Class<T> modelClass) {
        this.modelClass = modelClass;
    }


//  вместо листов и сетов использовать Iterable, можно итерироваться как угодно и запихнуть лист,лист и т.п
    //  пример ->  for(T t: itrbl)

    @Override
    public List<T> saveAll(Iterable<T> itrb) {
       // itrb.iterator();
        //for(T t: itrbl)
       return StreamSupport.stream(itrb.spliterator(), false) // если тру - многопоточка
                .map(entity->save(entity))
                .collect(Collectors.toList());
    }

    @Override
    public T save(T t) {
        Session session = createSession();
        ID id =(ID) session.save(t);
        Optional<T> result = getById(id, session);
        closeSession(session);
        return result.get();
    }

    @Override
    public void deleteById(ID id) {
        Session session = createSession();
        getById(id, session).ifPresent(entity -> session.remove(entity));
        closeSession(session);
    }

    @Override
    public Optional<T> findById(ID id) {
        Session session = createSession();
        Optional<T> result = getById(id, session);
        closeSession(session);
        return result;
    }

    @Override
    public List<T> findAll() {
        Session session = createSession();
        JpaCriteriaQuery<T> query = session.getCriteriaBuilder().createQuery(modelClass);
       // Query<T> sessionQuery = session.createQuery(query.select(query.from(modelClass)));
        List<T> resultList = session.createQuery(query.select(query.from(modelClass))).getResultList();
closeSession(session);
return resultList;

    }

    @Override
    public void close() {
        HibernateSessionFactory.close();
    }

//    @Override
    public Optional<T> getById(ID id, Session session) {
        return Optional.ofNullable(session.get(modelClass, id));
    }

    private Session createSession() {
        Session openSession = HibernateSessionFactory.getSessionFactory().openSession();
        openSession.beginTransaction();
        return openSession;
    }

    public void closeSession(Session session) {
        session.getTransaction().commit();
        session.close();
    }
}
