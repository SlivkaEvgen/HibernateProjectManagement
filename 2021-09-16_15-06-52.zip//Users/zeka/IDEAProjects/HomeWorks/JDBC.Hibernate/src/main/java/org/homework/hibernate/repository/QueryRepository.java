package org.homework.hibernate.repository;

import org.homework.hibernate.model.BaseModel;
import org.homework.hibernate.model.Developer;
import java.util.List;

public interface QueryRepository<T extends BaseModel<ID>, ID> {

    Long getDevsByProID(Long id, List<Developer> devInOnePro);

    List<T> listJava(String java);

    List<T> listMiddle(String middle);

    String listProWithData(List<T> devInOnePro);
}
