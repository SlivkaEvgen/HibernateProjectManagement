package org.homework.hibernate.client;

import org.hibernate.Session;
import org.homework.hibernate.model.*;
import org.homework.hibernate.utils.HibernateSessionFactory;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        // new CommandImpl().start();

        System.out.println("Hibernate tutorial");

        Session session = HibernateSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        List<Company> companyList = loadAllData(Company.class, session);
        List<Developer> developerList = loadAllData(Developer.class, session);
        List<Project> projectList = loadAllData(Project.class, session);
        List<Customer> customerList = loadAllData(Customer.class, session);
        List<Skill> skillList = loadAllData(Skill.class, session);

        System.out.println("*****************************************************************************");
///// GET ALL
//        System.out.println(companyList);
//
//        System.out.println(developerList);
//
//        System.out.println(projectList);
////
//        System.out.println(customerList);
////
//        System.out.println(skillList);
//////  GET BY ID
        System.out.println(" BY ID ");

//        System.out.println(companyList.get(0));
//
//        System.out.println(developerList.get(0));
//
//        System.out.println(projectList.get(0));
//
//        System.out.println(customerList.get(0));
//
//        System.out.println(skillList.get(0));


        session.getTransaction().commit();
        session.close();
    }

    private static <T> List<T> loadAllData(Class<T> type, Session session) {
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<T> criteria = builder.createQuery(type);
        criteria.from(type);
        List<T> data = session.createQuery(criteria).getResultList();
        return data;
    }

}
