//package org.homework.hibernate.controller.hw4.interfaces;
//
//public interface Controller {
//
//    void start();
//
//    void close();
//}
