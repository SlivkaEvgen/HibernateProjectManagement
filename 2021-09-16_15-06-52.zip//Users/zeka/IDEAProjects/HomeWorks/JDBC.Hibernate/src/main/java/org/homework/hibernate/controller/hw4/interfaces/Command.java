//package org.homework.hibernate.controller.hw4.interfaces;
//
//public interface Command extends Controller {
//
//    void getCommand();
//
//    void createCommand();
//
//    void updateCommand();
//
//    void deleteCommand();
//}
