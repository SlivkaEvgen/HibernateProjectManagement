package org.homework.hibernate.model;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = "developers")
@ToString(exclude = "developers")
@Entity
@Table(name = "skills")
public class Skill implements BaseModel<Long> {

    private static final long serialVersionUID = 1928544651928374654L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true, unique = true)
    private Long id;

    @Column(name = "activities", nullable = true, length = 30)
    private String activities;

    @Column(name = "level", nullable = true, length = 30)
    private String level;

    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(
            name = "developers_skills",
            joinColumns = {@JoinColumn(name = "developer_id")},
            inverseJoinColumns = {@JoinColumn(name = "skill_id")})
    private Set<Developer> developers;
}
